#include "emulation_aidc.h"

namespace vtb {

EmulationAidc::EmulationAidc() : PortHandler() {
   start();
}

void EmulationAidc::dequeue_packets() {}
void EmulationAidc::extract_metadata() {}
void EmulationAidc::decode_metadata() {}
void EmulationAidc::act_on_metadata() {}
void EmulationAidc::create_port_metadata() {}
void EmulationAidc::write_packets() {}
void EmulationAidc::read_packets() {}
void EmulationAidc::create_vm_metadata() {}
void EmulationAidc::enqueue_packets() {}

} // namespace vtb
