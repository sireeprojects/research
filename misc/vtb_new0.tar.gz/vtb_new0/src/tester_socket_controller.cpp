#include "tester_sockets_controller.h"

namespace vtb {

TesterSocketsController::TesterSocketsController() : PortController() {
   // Calling protected start() ensures Tester overrides are used
   start();
}

void TesterSocketsController::create_controller_events() {
   // Test-specific socket initialization
}

void TesterSocketsController::monitor_controller_events() {
   // Test-specific epoll registration
   launch_worker();
}

void TesterSocketsController::epoll_worker() {
   while (is_running_) {
      // Test-specific packet processing
   }
}

} // namespace vtb
