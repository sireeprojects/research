#include "emulation_virtual_machine.h"

namespace vtb {

EmulationVirtualMachine::EmulationVirtualMachine()
   : PortHandler() {
   start();
}

void EmulationVirtualMachine::dequeue_packets() {}
void EmulationVirtualMachine::extract_metadata() {}
void EmulationVirtualMachine::decode_metadata() {}
void EmulationVirtualMachine::act_on_metadata() {}
void
EmulationVirtualMachine::create_port_metadata() {}
void EmulationVirtualMachine::write_packets() {}
void EmulationVirtualMachine::read_packets() {}
void EmulationVirtualMachine::create_vm_metadata() {}
void EmulationVirtualMachine::enqueue_packets() {}

} // namespace vtb
