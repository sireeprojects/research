#include "port_controller.h"

namespace vtb {

PortController::PortController()
   : is_running_(false) {}

PortController::~PortController() {
   is_running_ = false;
   if (worker_.joinable()) {
      worker_.join();
   }
}

// Calls create then monitor in sequence.
void PortController::start() {
   create_controller_events();
   monitor_controller_events();
}

// Starts epoll_worker in a background thread.
// Derived monitor_controller_events() should call this.
void PortController::launch_worker() {
   if (!is_running_) {
      is_running_ = true;
      worker_ = std::thread(
         [this]{ epoll_worker(); });
   }
}

} // namespace vtb
