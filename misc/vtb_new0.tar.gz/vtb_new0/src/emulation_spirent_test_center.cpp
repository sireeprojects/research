#include "emulation_spirent_test_center.h"

namespace vtb {

EmulationSpirentTestCenter::EmulationSpirentTestCenter()
   : PortHandler() {
   start();
}

void EmulationSpirentTestCenter::dequeue_packets() {}
void EmulationSpirentTestCenter::extract_metadata() {}
void EmulationSpirentTestCenter::decode_metadata() {}
void EmulationSpirentTestCenter::act_on_metadata() {}
void
EmulationSpirentTestCenter::create_port_metadata() {}
void EmulationSpirentTestCenter::write_packets() {}
void EmulationSpirentTestCenter::read_packets() {}
void
EmulationSpirentTestCenter::create_vm_metadata() {}
void EmulationSpirentTestCenter::enqueue_packets() {}

} // namespace vtb
