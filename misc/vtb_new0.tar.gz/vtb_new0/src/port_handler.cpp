#include "port_handler.h"

namespace vtb {

PortHandler::PortHandler()
   : is_running_(false) {}

PortHandler::~PortHandler() {
   stop();
   if (tx_thread_.joinable())
      tx_thread_.join();
   if (rx_thread_.joinable())
      rx_thread_.join();
}

void PortHandler::start() {
   if (!is_running_) {
      is_running_ = true;
      tx_thread_ = std::thread([this]{tx_thread_func();});
      rx_thread_ = std::thread([this]{rx_thread_func();});
   }
}

void PortHandler::stop() {
   is_running_ = false;
}

// Runs the TX pipeline in a loop.
void PortHandler::tx_thread_func() {
   while (is_running_) {
      dequeue_packets();
      extract_metadata();
      decode_metadata();
      act_on_metadata();
      create_port_metadata();
      write_packets();
   }
}

// Runs the RX pipeline in a loop.
void PortHandler::rx_thread_func() {
   while (is_running_) {
      read_packets();
      extract_metadata();
      decode_metadata();
      act_on_metadata();
      create_vm_metadata();
      enqueue_packets();
   }
}

} // namespace vtb
