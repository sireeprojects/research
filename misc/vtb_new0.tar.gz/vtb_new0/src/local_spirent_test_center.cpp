#include "local_spirent_test_center.h"

namespace vtb {

LocalSpirentTestCenter::LocalSpirentTestCenter()
   : PortHandler() {
   start();
}

void LocalSpirentTestCenter::dequeue_packets() {}
void LocalSpirentTestCenter::extract_metadata() {}
void LocalSpirentTestCenter::decode_metadata() {}
void LocalSpirentTestCenter::act_on_metadata() {}
void LocalSpirentTestCenter::create_port_metadata() {}
void LocalSpirentTestCenter::write_packets() {}
void LocalSpirentTestCenter::read_packets() {}
void LocalSpirentTestCenter::create_vm_metadata() {}
void LocalSpirentTestCenter::enqueue_packets() {}

} // namespace vtb
