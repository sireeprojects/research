#include "local_aidc.h"

namespace vtb {

LocalAidc::LocalAidc() : PortHandler() {
   start();
}

void LocalAidc::dequeue_packets() {}
void LocalAidc::extract_metadata() {}
void LocalAidc::decode_metadata() {}
void LocalAidc::act_on_metadata() {}
void LocalAidc::create_port_metadata() {}
void LocalAidc::write_packets() {}
void LocalAidc::read_packets() {}
void LocalAidc::create_vm_metadata() {}
void LocalAidc::enqueue_packets() {}

} // namespace vtb
