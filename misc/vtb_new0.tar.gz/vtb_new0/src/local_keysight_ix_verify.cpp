#include "local_keysight_ix_verify.h"

namespace vtb {

LocalKeysightIxVerify::LocalKeysightIxVerify()
   : PortHandler() {
   start();
}

void LocalKeysightIxVerify::dequeue_packets() {}
void LocalKeysightIxVerify::extract_metadata() {}
void LocalKeysightIxVerify::decode_metadata() {}
void LocalKeysightIxVerify::act_on_metadata() {}
void LocalKeysightIxVerify::create_port_metadata() {}
void LocalKeysightIxVerify::write_packets() {}
void LocalKeysightIxVerify::read_packets() {}
void LocalKeysightIxVerify::create_vm_metadata() {}
void LocalKeysightIxVerify::enqueue_packets() {}

} // namespace vtb
