#include "local_virtual_machine.h"

namespace vtb {

LocalVirtualMachine::LocalVirtualMachine()
   : PortHandler() {
   start();
}

void LocalVirtualMachine::dequeue_packets() {}
void LocalVirtualMachine::extract_metadata() {}
void LocalVirtualMachine::decode_metadata() {}
void LocalVirtualMachine::act_on_metadata() {}
void LocalVirtualMachine::create_port_metadata() {}
void LocalVirtualMachine::write_packets() {}
void LocalVirtualMachine::read_packets() {}
void LocalVirtualMachine::create_vm_metadata() {}
void LocalVirtualMachine::enqueue_packets() {}

} // namespace vtb
