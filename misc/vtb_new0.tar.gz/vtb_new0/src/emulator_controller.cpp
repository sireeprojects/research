#include "emulator_controller.h"

namespace vtb {

EmulatorController::EmulatorController() : PortController() {
   start();
}

void EmulatorController::create_controller_events() {
   // Emulator-specific event creation
}

void EmulatorController::monitor_controller_events() {
   // Emulator-specific epoll registration
   launch_worker();
}

void EmulatorController::epoll_worker() {
   while (is_running_) {
      // Emulator-specific event processing
   }
}

} // namespace vtb
