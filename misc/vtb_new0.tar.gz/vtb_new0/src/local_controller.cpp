#include "local_controller.h"

namespace vtb {

LocalController::LocalController() : PortController() {
   start();
}

void LocalController::create_controller_events() {
   // Local-specific event creation
}

void LocalController::monitor_controller_events() {
   // Local-specific epoll registration
   launch_worker();
}

void LocalController::epoll_worker() {
   while (is_running_) {
      // Local-specific event processing
   }
}

} // namespace vtb
