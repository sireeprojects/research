#pragma once

#include "port_handler.h"

namespace vtb {

// Emulation port handler for Keysight IxVerify.
class EmulationKeysightIxVerify : public PortHandler {
public:
   EmulationKeysightIxVerify();
   virtual ~EmulationKeysightIxVerify() = default;

protected:
   void dequeue_packets() override;
   void extract_metadata() override;
   void decode_metadata() override;
   void act_on_metadata() override;
   void create_port_metadata() override;
   void write_packets() override;
   void read_packets() override;
   void create_vm_metadata() override;
   void enqueue_packets() override;
};

} // namespace vtb
