#pragma once

#include "port_controller.h"

namespace vtb {

// Derived controller for local socket communication.
class LocalController : public PortController {
public:
   LocalController();
   virtual ~LocalController() = default;

protected:
   void create_controller_events() override;
   void monitor_controller_events() override;
   void epoll_worker() override;
};

} // namespace vtb
