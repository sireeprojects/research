#pragma once

#include "port_controller.h"

namespace vtb {

// Derived controller for emulator communication.
class EmulatorController : public PortController {
public:
   EmulatorController();
   virtual ~EmulatorController() = default;

protected:
   void create_controller_events() override;
   void monitor_controller_events() override;
   void epoll_worker() override;
};

} // namespace vtb
