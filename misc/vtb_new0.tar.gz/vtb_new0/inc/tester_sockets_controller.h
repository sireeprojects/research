#pragma once

#include "port_controller.h"

namespace vtb {

class TesterSocketsController : public PortController {
public:
   // Constructor calls start() to initiate test-specific logic.
   TesterSocketsController();
   virtual ~TesterSocketsController() = default;

protected:
   void create_controller_events() override;
   void monitor_controller_events() override;
   void epoll_worker() override;
};

} // namespace vtb
