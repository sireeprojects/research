#pragma once

#include <atomic>
#include <thread>

namespace vtb {

// Abstract base class (interface) for port handling.
// TX and RX pipelines run on dedicated threads.
// All pipeline methods are protected and are not
// accessible to external users.
class PortHandler {
public:
   PortHandler();
   virtual ~PortHandler();

   PortHandler(const PortHandler&) = delete;
   PortHandler& operator=(
      const PortHandler&) = delete;

   // Starts both transmit and receive threads.
   void start();

   // Signals both threads to stop.
   void stop();

protected:
   // TX pipeline — called in sequence by the
   // transmit thread. Not accessible to users.
   virtual void dequeue_packets() = 0;
   virtual void extract_metadata() = 0;
   virtual void decode_metadata() = 0;
   virtual void act_on_metadata() = 0;
   virtual void create_port_metadata() = 0;
   virtual void write_packets() = 0;

   // RX pipeline — called in sequence by the
   // receive thread. Not accessible to users.
   // extract_metadata, decode_metadata, and
   // act_on_metadata are shared with TX pipeline.
   virtual void read_packets() = 0;
   virtual void create_vm_metadata() = 0;
   virtual void enqueue_packets() = 0;

private:
   // Thread entry points — run the pipeline loops.
   void tx_thread_func();
   void rx_thread_func();

   std::atomic<bool> is_running_;
   std::thread       tx_thread_;
   std::thread       rx_thread_;
};

} // namespace vtb
