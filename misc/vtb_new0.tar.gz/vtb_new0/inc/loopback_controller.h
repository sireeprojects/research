#pragma once

#include "port_controller.h"

namespace vtb {

class LoopbackController : public PortController {
public:
   // Constructor calls start() to initiate loopback-specific logic.
   LoopbackController();
   virtual ~LoopbackController() = default;

protected:
   void create_controller_events() override;
   void monitor_controller_events() override;
   void epoll_worker() override;
};

} // namespace vtb
