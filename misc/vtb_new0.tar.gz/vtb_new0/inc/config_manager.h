#pragma once

#include "cmdline_parser.h"
#include "messenger.h"
#include "common.h"

#include <unordered_map>
#include <map>
#include <any>
#include <mutex>
#include <optional>

namespace vtb {

class ConfigManager {
public:
   static ConfigManager& get_instance();
   ConfigManager(const ConfigManager&) = delete;
   ConfigManager& operator=(const ConfigManager&) = delete;

   bool init(int argc, char** argv);

   template<typename T>
   T get_arg(std::string_view name) const { return parser_.get<T>(name); }

   template<typename T>
   void set_value(const std::string& key, T&& value) {
      std::lock_guard<std::mutex> lock(db_mutex_);
      database_[key] = std::make_any<
         typename std::decay<T>::type>(
         std::forward<T>(value));
   }

   template<typename T>
   std::optional<T> get_value(const std::string& key) const {
      std::lock_guard<std::mutex> lock(db_mutex_);
      auto it = database_.find(key);
      if (it != database_.end()) {
         try { return std::any_cast<T>(it->second); } catch (...) {}
      }
      return std::nullopt;
   }

   void dump_config();

   void init_vhost_device(int port_id, int vid, int nof_pairs);
   void set_queue_state(int port_id, uint16_t vring_id, bool enable);
   void assign_port_socket(int port_id, int qp_idx, int socket_fd);
   void assign_control_path(int port_id, int ctl_fd);

private:
   ConfigManager();
   ~ConfigManager();

   CmdlineParser parser_;
   std::unordered_map<std::string, std::any> database_;
   mutable std::mutex db_mutex_;

   std::map<int, PortMap> pmap_;
   mutable std::mutex pmap_mutex_;
};

} // namespace vtb
