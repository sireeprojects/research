#pragma once

#include <thread>
#include <atomic>

namespace vtb {

// Abstract base class for managing port lifecycles.
// create_controller_events, monitor_controller_events
// and epoll_worker are protected — not accessible
// to external users.

class PortController {
public:
   PortController();

   // Virtual destructor ensures derived cleanup.
   virtual ~PortController();

   // Prevent copying to maintain unique ownership
   // of the thread.
   PortController(const PortController&) = delete;
   PortController& operator=(const PortController&) = delete;

   // Calls create_controller_events() then
   // monitor_controller_events() in sequence.
   void start();

protected:
   // Pure virtual — must be implemented by derived
   // class. Not accessible to external users.
   virtual void create_controller_events() = 0;
   virtual void monitor_controller_events() = 0;
   virtual void epoll_worker() = 0;

   // Starts epoll_worker in a background thread.
   // Call this from monitor_controller_events().
   void launch_worker();

   std::atomic<bool> is_running_;
   std::thread worker_;
};

} // namespace vtb
